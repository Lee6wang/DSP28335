/*
 * main.c
 *
 *  Created on: 2018-3-21
 *      Author: Administrator
 */


#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File

#include "leds.h"
#include "time.h"
#include "uart.h"



/*******************************************************************************
* �� �� ��         : main
* ��������		   : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
void main()
{
	int i=0;
	Uint16 SendChar=0;
	Uint16 ReceivedChar=0;

	InitSysCtrl();
	InitPieCtrl();
	IER = 0x0000;
	IFR = 0x0000;
	InitPieVectTable();

	LED_Init();
	TIM0_Init(150,200000);//200ms
	UARTa_Init(9600);

	while(1)
	{
		UARTa_SendByte(SendChar);
		// Check received character
		ReceivedChar = SciaRegs.SCIRXBUF.all;
		if(ReceivedChar != SendChar)LED2_TOGGLE;
		DELAY_US(100*1000);

		// Move to the next character and repeat the test
		SendChar++;
		// Limit the character to 8-bits
		SendChar &= 0x00FF;
	}
}

