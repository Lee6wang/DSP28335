/*
 * secwatch.h
 *
 *  Created on: 2018-2-3
 *      Author: Administrator
 */

#ifndef SECWATCH_H_
#define SECWATCH_H_

#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�


void SECWatch_Display(unsigned char sec,unsigned char mms);

#endif /* SECWATCH_H_ */
