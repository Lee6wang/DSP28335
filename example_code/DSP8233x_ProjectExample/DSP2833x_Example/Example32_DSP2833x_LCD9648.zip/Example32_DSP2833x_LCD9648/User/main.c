/*
 * main.c
 *
 *  Created on: 2018-3-21
 *      Author: Administrator
 */


#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File

#include "leds.h"
#include "time.h"
#include "uart.h"
#include "stdio.h"
#include "lcd9648.h"


void delay(void)
{
    Uint16 		i;
	Uint32      j;
	for(i=0;i<32;i++)
		for (j = 0; j < 100000; j++);
}

/*******************************************************************************
* �� �� ��         : main
* ��������		   : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
void main()
{
	unsigned char i=0;


	InitSysCtrl();
	InitPieCtrl();
	IER = 0x0000;
	IFR = 0x0000;
	InitPieVectTable();


	LED_Init();
	TIM0_Init(150,200000);//200ms
	UARTa_Init(4800);
	LCD9648_Init();
	LCD9648_Clear();
	LCD9648_Write16CnCHAR(15,0,"���пƼ�");

	while(1)
	{
		for(i = 0; i < 5; i+=2)
		{
			LCD9648_Write16CnCHAR(15,i,"���пƼ�");
			DELAY_US(1000000);
			LCD9648_Clear();
		}
//		LCD9648_ClearTest();
	}
}


