/*
 * main.c
 *
 *  Created on: 2018-3-21
 *      Author: Administrator
 */

#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File

#include "leds.h"
#include "time.h"
#include "uart.h"
#include "stdio.h"
#include "dma.h"



#define DMA_BUF_SIZE 1024
#pragma DATA_SECTION(DMABuf1,"DMARAML4");
#pragma DATA_SECTION(DMABuf2,"ZONE7DATA");

volatile Uint16 DMABuf1[DMA_BUF_SIZE];
volatile Uint16 DMABuf2[DMA_BUF_SIZE];


/*******************************************************************************
* �� �� ��         : main
* ��������		   : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
void main()
{
	Uint16 i=0;
	Uint16 j=0;

	InitSysCtrl();
	InitPieCtrl();
	IER = 0x0000;
	IFR = 0x0000;
	InitPieVectTable();

	LED_Init();
	TIM0_Init(150,200000);//200ms
	UARTa_Init(4800);

	DMACH1_Init(DMABuf1,DMABuf2);
	// Initialize Tables
	for (i=0; i<DMA_BUF_SIZE; i++)
	{
		DMABuf1[i] = 0;
		DMABuf2[i] = i;
	}
	StartDMACH1();

	while(1)
	{
		j++;
		if(j%200==0)
		{
			LED6_TOGGLE;
		}
		DELAY_US(1000);
	}
}

