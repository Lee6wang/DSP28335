/*
 * eqep.h
 *
 *  Created on: 2018��7��12��
 *      Author: Administrator
 */

#ifndef EQEP_H_
#define EQEP_H_


#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"



void EPwm1Setup(void);
void EQEP1_Init(void);
#endif /* APP_EQEP_EQEP_H_ */
