///////////////////////////hal.h//////////////////////////

unsigned short WordSwap(unsigned short input);
void DelayMs(unsigned int nFactor);
unsigned long SwapINT32(unsigned long dData);
unsigned int SwapINT16(unsigned short dData);

unsigned int LSwapINT16(unsigned short dData1,unsigned short dData2);
unsigned long LSwapINT32(unsigned long dData1,unsigned long dData2,unsigned long dData3,unsigned long dData4);
