

#ifndef DSP2833x_InitDSP_H
#define DSP2833x_InitDSP_H

#include "includes.h"


void InitDSP();






#endif  // end of DSP2833x_InitDSP_H definition

//===========================================================================
// End of file.
//===========================================================================











