/*
 * can.h
 *
 *  Created on: 2021��5��29��
 *      Author: YZ
 */

#ifndef _CAN_H_
#define _CAN_H_


#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�


void CANB_Init(void);
void CanBSend(Uint32 Can_Id, char length, Uint32 Data_L, Uint32 Data_H);
void CANB_Recv_ISR(void);
#endif /* APP_CAN_CAN_H_ */
