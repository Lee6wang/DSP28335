/*
 * aic23.h
 *
 *  Created on: 2018��8��24��
 *      Author: Administrator
 */

#ifndef AIC23_H_
#define AIC23_H_


#include "DSP2833x_Device.h"     // DSP2833x ͷ�ļ�
#include "DSP2833x_Examples.h"   // DSP2833x �������ͷ�ļ�



void I2CA_Init(void);
Uint16 AIC23Write(int Address,int Data);



#endif /* APP_AIC23_AIC23_H_ */
